import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import jwtDecode from 'jwt-decode'; // Ensure jwtDecode is imported
import NotificationPanel from './NotificationPanel'; 
import './styles/index.css';

const sections = [
  { title: 'Prerequisite Waiver', icon: '📝', description: 'Click to proceed', link: '/PrerequisiteWaiver' },
  { title: 'StudentInfo', icon: '🎓', description: 'View student information', link: '/StudentInfo' },  
  { title: 'Tasks', icon: '⚠', description: 'No current tasks' },
];

function Dashboard() {
  const [fullName, setFullName] = useState(''); // Store the full name
  const navigate = useNavigate();

  useEffect(() => {
    // Retrieve the token from localStorage
    const token = localStorage.getItem('token');

    if (token) {
      try {
        const decoded = jwtDecode(token); // Decode the token
        const email = decoded?.username;

        if (email) {
          // Fetch student's first and last name based on the email
          fetch(`/api/student/${email}`)
            .then((res) => res.json())
            .then((data) => {
              if (data.first_name && data.last_name) {
                setFullName(`${data.first_name} ${data.last_name}`);
              } else {
                console.error("Student's name not found.");
              }
            })
            .catch((err) => console.error('Error fetching student data:', err));
        } else {
          console.error("Token does not contain a valid email.");
        }
      } catch (error) {
        console.error('Failed to decode token:', error);
      }
    } else {
      console.warn('No token found, user may not be logged in.');
      navigate('/login'); // Redirect to login if no token
    }
  }, [navigate]);

  const handleClick = (link) => {
    navigate(link);
  };

  return (
    <div className="dashboard-container">
      <div className="main-content">
        <header className="dashboard-header">
          <h1>Welcome, {fullName || 'Student'}!</h1> {/* Display the student's full name */}
        </header>
        <div className="dashboard-cards">
          {sections.map((section, index) => (
            <div
              key={index}
              className={`dashboard-card ${section.link ? 'clickable' : ''}`}
              onClick={() => section.link && handleClick(section.link)}
            >
              <div className="card-icon">{section.icon}</div>
              <h3>{section.title}</h3>
              <p>{section.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Notification Panel */}
      <NotificationPanel />
    </div>
  );
}

export default Dashboard;
